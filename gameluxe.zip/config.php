// Tripay
define('TRIPAY_API_KEY', 'APIKEYMU');
define('TRIPAY_PRIVATE_KEY', 'PRIVATEKEYMU');
define('TRIPAY_MERCHANT_CODE', 'MERCHANTMU');

// Digiflazz
define('DIGIFLAZZ_API_KEY', 'APIKEYDIGI');
define('DIGIFLAZZ_USERNAME', 'USERNAME');

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'nama_database_kamu');
define('DB_USER', 'username_database_kamu');
define('DB_PASS', 'password_database_kamu');